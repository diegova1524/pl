<script setup lang="ts"></script>

<template>
  <div>Proveedores</div>
</template>

<style scoped></style>
